================================================================================
FWA 5G BAND n50 (80 MHz) — EXECUTIVE MEETING PACK (SEPTEMBER 2026)
================================================================================

This meeting pack contains two separate, focused presentation decks and models:

--------------------------------------------------------------------------------
DECK A: 3-BTS PAMPANGA PILOT TRIAL & DEMONSTRATION PLAN (7 SLIDES)
--------------------------------------------------------------------------------
Dedicated strictly to the technical trial, NTC permits, and RF propagation demo.
Zero commercial claims or premature status assertions.

Files:
  - PowerPoint:  FWA_5G_Trial_Demo_Status_Update.pptx (or FWA_5G_Project_Status_Update.pptx)
  - Interactive: FWA_5G_Trial_Demo_Status_Update_Standalone.html (or FWA_5G_Project_Status_Update_Standalone.html)
    (100% offline, zero-dependency, editable text, exportable)

Slide Outline (7 Slides):
  - Slide 01: Title & Trial Mandate (Dolores, Reliance IT, Comclark NOC)
  - Slide 02: 3-Site Fixed Wireless Access Trial Network Architecture
  - Slide 03: Pilot Site Selection & Geographic Coverage Profiles
  - Slide 04: Starlink Satellite Backhaul Integration Architecture
  - Slide 05: Regulatory Compliance & Spectrum Rights (NTC BSD-0196 & BSD-0197-2026)
  - Slide 06: Propagation Trial Methodology & 5-Phase Testing Framework
  - Slide 07: Technical & Operational Risk Assessment Matrix

--------------------------------------------------------------------------------
DECK B: DICT GIDA BARANGAY ROLLOUT PLAN & COMMERCIAL EXPANSION (10 SLIDES)
--------------------------------------------------------------------------------
Dedicated strategic commercial deck incorporating DICT's 42,001 barangay ranking.

Files:
  - PowerPoint:  FWA_5G_DICT_GIDA_Rollout_Plan.pptx
  - Interactive: FWA_5G_DICT_GIDA_Rollout_Plan_Standalone.html
    (100% offline, zero-dependency, editable text, exportable)

Slide Outline (10 Slides):
  - Slide 01: Title & Commercial Mandate (TelTech & Comclark)
  - Slide 02: Executive Rationale: Sub-2GHz Band n50 + Starlink Backhaul
  - Slide 03: DICT GIDA Dataset Analysis: 42,001 Evaluated Barangays & 4 Tiers
  - Slide 04: The Macro-Cell Clustering Engine (3.5 km Radius = 3.9 Brgys / Tower)
  - Slide 05: 1,000-Site Year 1 Regional Quotas (Top 18 Provincial Regions)
  - Slide 06: Region III Operational Bridge (Pampanga Trial into 41 Macro Sites)
  - Slide 07: 4-Phase Nationwide Rollout Roadmap (1,000 to 10,000 Sites)
  - Slide 08: The Dual-Revenue Commercial Engine (DICT Subsidy + ₱599 Retail)
  - Slide 09: Macro Site Unit Economics & Payback (₱395.4k/mo, 10.4-mo Payback)
  - Slide 10: 10-Year Commercial Valuation ($1.07B NPV) & 90-Day Execution Matrix

--------------------------------------------------------------------------------
SUPPORTING DELIVERABLES & MODELS
--------------------------------------------------------------------------------
1. Strategic Analysis Report:
   - DICT_GIDA_Barangay_Rollout_Plan.md
2. 3 Financial Models (Excel):
   - 01_FWA_n50_Dynamic_Business_Case_Baseline.xlsx (+$294.6M NPV, 17.7% IRR)
   - 02_FWA_n50_Business_Case_Dynamic_ARPU_Tier_Migration.xlsx (+$686.3M NPV, 26.8% IRR)
   - 03_FWA_n50_Business_Case_Best_Case_Scenario.xlsx (+$1,068.0M NPV, 37.6% IRR)
3. 20-Slide Board Business Case:
   - FWA_5G_Strategic_Business_Case_20Slides_Standalone.html
================================================================================
