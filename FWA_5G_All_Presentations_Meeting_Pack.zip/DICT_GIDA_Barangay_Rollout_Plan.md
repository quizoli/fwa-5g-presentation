# Executive Strategic Plan: DICT GIDA Barangay Prioritization & Phased 5G FWA Rollout

**Document ID:** TELTECH-COMCLARK-FWA-GIDA-PLAN-2026  
**Date:** September 2026  
**Target Entity:** Telecommunications Technology Solutions Inc. (TelTech) & Comclark Network and Technology Corp.  
**Spectrum Asset:** Band n50 (1432–1517 MHz, 80 MHz Contiguous Nationwide Spectrum) & Band n77 (3.7 GHz)  
**Primary Backhaul:** Starlink Business LEO Satellite & Microwave Relays  
**Dataset Source:** Department of Information and Communications Technology (DICT) Free Public Internet Access Program (FPIAP) GIDA Barangay Prioritization Tool (42,001 Nationwide Records)

---

## 1. Executive Summary & Strategic Rationale

The Philippine telecommunications landscape suffers from a structural broadband divide: while National Capital Region (NCR) and tier-1 metropolitan corridors are saturated with competing fiber-to-the-home (FTTH) networks, **provincial and rural municipalities (Class 3 to 6) remain severely unserved**. Terrestrial fiber trenching across mountainous terrain, remote islands, and isolated rural barangays carries negative return on investment (ROI) for legacy telcos (PLDT, Globe, DITO) due to prohibitive civil works and right-of-way (ROW) costs.

By pairing **TelTech/Comclark's 80 MHz contiguous nationwide spectrum in Band n50 (1.5 GHz)** with **Starlink LEO Satellite Backhaul**, TelTech possesses a unique technological and economic moat:
1. **Sub-2GHz Propagation Superiority:** Band n50 delivers a **3.5 km non-line-of-sight (NLOS) rural radius** (~38.5 km² coverage area per tower), penetrating dense tropical foliage and rain where 3.5 GHz (C-band) fails.
2. **Zero-Trenching Rapid Deployment:** Using Starlink LEO satellite backhaul (220+ Mbps down, 25–40 Mbps up, <40ms latency), a macro cell tower can be deployed, integrated, and commissioned in **48 to 72 hours**, requiring zero local civil fiber trenching.
3. **Dual-Revenue Engine (Anchor Subsidy + Retail Cash Flow):**
   - **Anchor Government Subsidy:** DICT allocates billions annually under the Free Public Internet Access Program (FPIAP) and Universal Access Fund (UAF) to connect Geographically Isolated and Disadvantaged Areas (GIDA). TelTech can capture managed service fees of **₱15,000–₱25,000/month per institutional site** (Barangay Halls, Rural Health Units, Public Elementary and High Schools).
   - **Commercial Residential Retail:** The remaining tower capacity is sold to surrounding households at **₱599/month for 50 Mbps unlimited FWA**, capturing 600 active subscribers per site (~₱360,000/month).
   - **Site Economics:** Combined monthly revenue of **₱390,000–₱410,000 per macro tower** delivers an operational payback of **under 14 months**.

---

## 2. DICT GIDA Dataset Analysis & Breakdown

The official DICT FPIAP prioritization tool evaluates **42,001 barangays** nationwide, assigning a GIDA score from **7.64 to 63.17**. Scores are calculated based on:
- Absence of fixed terrestrial broadband infrastructure
- Distance from nearest municipal center / optical transport pop
- Lack of commercial cellular mobile coverage
- Poverty incidence and municipal income classification
- Density of public institutional facilities (schools, health centers, government halls)

### 2.1. Nationwide & Provincial Distribution

| GIDA Priority Tier | GIDA Score Range | Nationwide Barangays | Provincial Barangays (Ex-NCR) | Rollout Phase |
| :--- | :--- | :--- | :--- | :--- |
| **Tier 1: Critical GIDA** | $\ge 50.0$ | **1,577** (3.8%) | **1,345** (3.3%) | **Phase 1 (Year 1)** |
| **Tier 2: High GIDA** | $40.0 - 49.9$ | **3,931** (9.4%) | **2,558** (6.3%) | **Phase 1 & Phase 2 (Years 1–3)** |
| **Tier 3: Moderate GIDA** | $30.0 - 39.9$ | **5,232** (12.5%) | **5,128** (12.7%) | **Phase 3 (Years 4–6)** |
| **Tier 4: Low / Minimal GIDA** | $< 30.0$ | **31,261** (74.3%) | **31,260** (77.6%) | **Phase 4 (Years 7–10)** |
| **Total** | | **42,001** | **40,291** | **10,000 Macro Sites** |

*Note on NCR: 232 barangays in NCR have scores $\ge 50$ due to high density of unserved informal settlements and poverty metrics, but are excluded from provincial macro planning to focus on unserved rural markets where fiber is completely absent.*

---

## 3. Macro-Cell Clustering & Year 1 Site Allocation (1,000 Sites)

### 3.1. The 3.9 Barangays-per-Site Clustering Model
In provincial municipalities, adjacent barangays share contiguous borders. With a **3.5 km macro coverage radius** from an 18–25m tower, a single Band n50 macro cell covers an area of **~38.5 km²**. Across rural terrain, this footprint comfortably encompasses **3 to 5 contiguous barangays**.

Across the 40,291 provincial barangays, there are **3,903 Priority 1 Barangays** (1,345 Critical + 2,558 High GIDA) across **831 municipalities**.
$$\text{Required Sites} = \frac{3,903 \text{ Priority Barangays}}{3.9 \text{ Barangays / Site}} = \mathbf{1,000 \text{ Macro Sites}}$$

This aligns **1:1 with our approved Year 1 Capital Expenditure budget of 1,000 Macro Sites**.

### 3.2. Balanced Regional Quota Allocation (1,000 Sites)

| Region | Priority 1 Barangays (Crit + High) | Critical Brgys ($\ge 50$) | High Brgys ($40-49.9$) | Municipalities | Year 1 Macro Sites | Brgys Covered / Site |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **Region IV-A (Calabarzon)** | 605 | 90 | 515 | 73 | **156** | 3.9 |
| **Region VIII (Eastern Visayas)** | 469 | 162 | 307 | 88 | **120** | 3.9 |
| **BARMM (Lanao/Maguindanao/SGA)** | 370 | 100 | 270 | 68 | **95** | 3.9 |
| **Region VI (Western Visayas)** | 314 | 202 | 112 | 47 | **80** | 3.9 |
| **CAR (Cordillera Admin Region)** | 294 | 103 | 191 | 60 | **75** | 3.9 |
| **BARMM (BaSulTa - Basilan/Sulu/Tawi-Tawi)** | 275 | 124 | 151 | 37 | **70** | 3.9 |
| **Region II (Cagayan Valley)** | 216 | 118 | 98 | 61 | **55** | 3.9 |
| **Region X (Northern Mindanao)** | 208 | 91 | 117 | 52 | **53** | 3.9 |
| **Region XI (Davao Region)** | 174 | 76 | 98 | 32 | **45** | 3.9 |
| **Region III (Central Luzon)** | 159 | 39 | 120 | 42 | **41** | 3.9 |
| **Region I (Ilocos Region)** | 152 | 63 | 89 | 42 | **39** | 3.9 |
| **Region V (Bicol Region)** | 146 | 58 | 88 | 61 | **37** | 3.9 |
| **Region IV-B (MIMAROPA)** | 134 | 40 | 94 | 40 | **34** | 3.9 |
| **Region IX (Zamboanga Peninsula)** | 124 | 27 | 97 | 42 | **32** | 3.9 |
| **Region VII (Central Visayas)** | 94 | 7 | 87 | 24 | **24** | 3.9 |
| **Region XIII (Caraga)** | 70 | 6 | 64 | 29 | **18** | 3.9 |
| **NIR (Negros Island Region)** | 57 | 29 | 28 | 13 | **15** | 3.8 |
| **Region XII (SOCCSKSARGEN)** | 42 | 10 | 32 | 20 | **11** | 3.8 |
| **NATIONWIDE TOTAL** | **3,903** | **1,345** | **2,558** | **831** | **1,000** | **3.9** |

---

## 4. Immediate Pilot-to-Commercial Transition: Region III (Central Luzon)

A critical requirement of executive management is maintaining a clear bridge between the current **3-BTS Pilot Trial in Pampanga** and commercial deployment. Region III represents the ideal operational springboard:
- **Pilot Foundation:** 3 BTS sites in Mabalacat, Angeles City, and Pasig establish baseline RF calibration, Starlink backhaul latency profiles, and NTC compliance.
- **Immediate Commercial Expansion:** Region III contains **159 Priority 1 GIDA barangays** (39 Critical, 120 High GIDA) concentrated in:
  - **Nueva Ecija:** 15 Critical, 21 High GIDA barangays (Cabanatuan City, General Mamerto Natividad, Llanera, San Jose).
  - **Aurora:** 15 Critical, 4 High GIDA barangays (Baler, Casiguran, Dilasag).
  - **Zambales:** 4 Critical, 2 High GIDA barangays.
  - **Bulacan / Pampanga / Bataan:** 6 Critical, 87 High GIDA barangays in rural agricultural and coastal pockets.
- **Operational Allocation:** Deploying **41 macro sites in Region III** during Phase 1 immediately covers all 159 Priority GIDA barangays, leveraging existing Clark logistics hubs, field engineers, and Comclark NOC infrastructure.

---

## 5. 4-Phase Nationwide Rollout Roadmap (10,000 Sites)

```
[Phase 1: Year 1]  ===> 1,000 Sites  | 3,903 Priority 1 Brgys (100% Critical + High GIDA) | 600,000 Subs Cap
[Phase 2: Y2 - Y3] ===> 2,000 Sites  | 5,232 Moderate GIDA + Expansion Corridors         | 1,800,000 Cum Subs
[Phase 3: Y4 - Y6] ===> 3,000 Sites  | Underserved Class 3-4 Municipalities               | 3,600,000 Cum Subs
[Phase 4: Y7 - Y10]===> 4,000 Sites  | Full Nationwide Infill & Densification (10k Sites)| 6,000,000 Active Subs
```

### Phase 1 (Year 1: 1,000 Macro Sites)
- **Geographic Scope:** Top 18 provincial regions, prioritizing Region IV-A (156 sites), Region VIII (120 sites), BARMM (165 sites combined), Region VI (80 sites), CAR (75 sites), Region II (55 sites), and Region III (41 sites).
- **Target Coverage:** 100% of provincial Critical GIDA barangays (1,345 brgys) and 2,558 High GIDA barangays.
- **Population Reach:** ~2.4 million households in footprint; 600,000 target subscribers (25% initial penetration).
- **Backhaul Mix:** 75% Starlink Business LEO, 20% microwave relays, 5% existing Comclark fiber PoPs.

### Phase 2 (Years 2–3: +2,000 Sites $\rightarrow$ 3,000 Cumulative)
- **Geographic Scope:** Densification across Western/Central/Eastern Visayas, Northern Luzon, and Mindanao agricultural corridors.
- **Target Coverage:** Remaining High GIDA and Tier 3 Moderate GIDA barangays (scores 35–45).
- **Subscribers:** Scaling to 1.8 million active residential connections.
- **Backhaul Evolution:** Transitioning high-traffic macro sites from Starlink to microwave rings and terrestrial fiber drops as regional transport expands.

### Phase 3 (Years 4–6: +3,000 Sites $\rightarrow$ 6,000 Cumulative)
- **Geographic Scope:** Class 3–4 semi-urban municipalities and suburban fringe areas where cable/copper is being retired.
- **Target Coverage:** Full coverage of all Moderate GIDA barangays (scores 30–39.9) and high-density municipal centers.
- **Subscribers:** Reaching 3.6 million active subscribers.

### Phase 4 (Years 7–10: +4,000 Sites $\rightarrow$ 10,000 Cumulative)
- **Geographic Scope:** Nationwide saturation across all 81 provinces and 1,489 municipalities.
- **Capacity:** Sized for 6.0+ million active subscribers (10M peak capacity), fulfilling the 10-year unicorn business case ($1.07B NPV, 37.6% IRR).

---

## 6. Financial Mechanics: The Dual-Revenue Model

Each macro site operates under a blended public-private partnership (PPP) and commercial retail framework:

### 6.1. Site Revenue Profile (Monthly per Tower)
1. **Public Sector Anchor Tenant (DICT FPIAP):**
   - 2 connected public institutions per macro tower (e.g., Barangay Hall + Public High School)
   - Contracted managed service rate: ₱18,000 / site / month
   - Subtotal: **₱36,000 / month** (Guaranteed government cash flow)
2. **Commercial Residential Retail:**
   - 600 active subscribers per tower at maturity (out of 2,500–4,000 households in 3.5 km radius)
   - Retail ARPU: ₱599 / month (Unlimited 50 Mbps Band n50)
   - Subtotal: **₱359,400 / month**
3. **Total Gross Revenue per Site:** **₱395,400 / month** (~₱4,744,800 / year)

### 6.2. Site OPEX Profile (Monthly per Tower)
- TowerCo Lease (Colocation / Ground Lease): **₱98,000 / month** (negotiated under bulk 1,000-site MLA)
- Starlink Business Backhaul (Pooled Enterprise Tier): **₱14,000 / month**
- Power & Generator Fuel: **₱25,000 / month**
- Site Maintenance, Security & Spares: **₱12,000 / month**
- Total OPEX per Site: **₱149,000 / month**

### 6.3. Net Site Economics & Payback
- **Monthly Operating EBITDA:** ₱395,400 − ₱149,000 = **₱246,400 / month** (62.3% EBITDA margin)
- **Total Initial CAPEX per Site:** ~$45,000 (₱2,565,000) including 3-sector n50 gNodeB, Starlink terminal, power systems, and installation.
- **Simple Payback Period:**
  $$\text{Payback} = \frac{\text{₱}2,565,000}{\text{₱}246,400 / \text{month}} = \mathbf{10.4 \text{ Months}}$$
- Even under conservative Mode 1 ramp-up (25% initial subscriber fill), payback is achieved in **under 14 months**.

---

## 7. Implementation Workstreams & 90-Day Execution Matrix

| Timeframe | Workstream | Key Deliverables & Action Items | Owner |
| :--- | :--- | :--- | :--- |
| **Days 1–30** | **Pilot Validation & NTC Reporting** | Finalize 30-day RF trial across Pampanga demo sites (Mabalacat, Angeles, Pasig). Submit technical report to NTC proving Band n50 propagation and Starlink latency stability. | Regulatory & Engineering |
| **Days 15–45** | **TowerCo Master Lease Agreements** | Finalize colocation MLAs with TowerCos (PhilTower, EdgePoint, edotco) covering the first 1,000 site coordinates mapped from the GIDA clusters. | Rollout & Acquisition |
| **Days 30–60** | **DICT FPIAP Bid & Starlink Enterprise Facility** | Submit qualified bids for DICT FPIAP regional connectivity tenders for Region III, IV-A, VI, and VIII. Execute enterprise capacity pooling agreement with Starlink. | Commercial & Legal |
| **Days 45–90** | **OEM Vendor Financing Facility** | Execute 15% down, 85% vendor deferred payment facility for initial 1,000 Band n50 macro base stations. | Chief Financial Officer |
| **Days 60–120** | **Phase 1 Site Construction & Launch** | Commence batch rollout of 100 sites/month across Region III (Central Luzon) and Region IV-A (Calabarzon). Initiate pre-sales in target barangays. | Project Management Office |

---

## 8. Conclusion & Recommendation

Integrating the **DICT GIDA Prioritization dataset** transforms the FWA business case from a theoretical municipality-level spreadsheet into a **geospatially validated, bankable deployment master plan**. 

By targeting the **3,903 Priority 1 GIDA barangays** with **1,000 macro sites in Year 1**, TelTech and Comclark secure immediate anchor government revenue, dominate unserved provincial residential broadband markets, and build the foundation for a nationwide 10,000-site telecommunications unicorn.
